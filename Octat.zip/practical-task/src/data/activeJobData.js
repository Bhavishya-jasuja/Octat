

// Sample ActiveJobData
const ActiveJobData = {
  type: 'Active Jobs',
  countPerDay: {
    Received: [26, 45, 77, 45, 95, 22, 65, 30, 100, 22, 53, 81, 22, 65, 88, 50, 28, 100, 22, 74, 25, 69, 22, 65, 34, 74, 43, 22, 69, 22],
    Applied: [28, 45, 77, 45, 95, 22, 65, 30, 100, 22, 53, 81, 22, 65, 88, 50, 28, 100, 22, 74, 25, 69, 22, 65, 34, 74, 43, 22, 69, 22],
  },
  jobData: [
    {
      id: 1,
      name: 'Interventional Cardiologist',
      location: 'New York City, USA',
      posted: '25th May',
      status: 'Published',
      applied: 98,
      jobViews: 128,
      daysLeft: 2,
      premium: false,
      dateFormat: '2023-05-25',
    },
    {
      id: 2,
      name: 'Dentist',
      location: 'Delhi, India',
      posted: '25th May',
      status: 'Published',
      applied: 68,
      jobViews: 150,
      daysLeft: 7,
      premium: false,
      dateFormat: '2023-05-25',
    },
    {
      id: 3,
      name: 'Doctor',
      location: 'Ahmedabad, India',
      posted: '25th May',
      status: 'Published',
      applied: 105,
      jobViews: 200,
      daysLeft: 30,
      premium: true,
      dateFormat: '2023-05-25',
    },
    {
      id: 4,
      name: 'Cardiologist',
      location: 'New York City, USA',
      posted: '24th May',
      status: 'Published',
      applied: 55,
      jobViews: 160,
      daysLeft: 7,
      premium: false,
      dateFormat: '2023-05-24',
    },
    {
      id: 5,
      name: 'Specialist',
      location: 'Colombo, India',
      posted: '23rd May',
      status: 'Published',
      applied: 40,
      jobViews: 100,
      daysLeft: 7,
      premium: false,
      dateFormat: '2023-05-23',
    },
  ],
};

export default ActiveJobData;

// export default ActiveJobData;
  