import React from 'react';

export default function NotFound() {
	return (
		<h2 style={{textAlign: 'center'}}>
            Page Not Found
        </h2>
	);
}