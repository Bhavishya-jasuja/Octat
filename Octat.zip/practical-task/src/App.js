import './App.css';
import { RouteContainer } from './routes';

function App() {
  return (
    <RouteContainer />
  );
}

export default App;
