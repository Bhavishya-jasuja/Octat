// const express=require("express");
// const app = express();

// app.listen(3001)



// import express from 'express';
// import {ActiveJobData} from './data/activeJobData';

// const app = express();
// const PORT = 3000;

// // API Endpoint to Get all active jobs
// app.get('/api/active-jobs', (req, res) => {
//   res.json(ActiveJobData.jobData);
// });

// // API Endpoint to Get a specific job by ID
// app.get('/api/active-jobs/:id', (req, res) => {
//   const jobId = parseInt(req.params.id);
//   const job = ActiveJobData.jobData.find((job) => job.id === jobId);

//   if (job) {
//     res.json(job);
//   } else {
//     res.status(404).json({ message: 'Job not found' });
//   }
// });

// // API Endpoint to Get job analytics
// app.get('/api/active-jobs/analytics', (req, res) => {
//   // You can calculate and return the analytics based on ActiveJobData
//   const analytics = {
//     countReceived: ActiveJobData.countPerDay.Received,
//     countApplied: ActiveJobData.countPerDay.Applied,
//   };
//   res.json(analytics);
// });

// app.listen(PORT, () => {
//   console.log(`Server is running on http://localhost:${PORT}`);
// });



const express = require('express');
const app = express();

const dbConnect = require("./config/database");

require("dotenv").config();

const PORT = process.env.port || 5000;

//middlewares
app.use(express.json());

const auth = require("./routes/auth");
app.use('/api/v1/',auth);

app.listen(PORT,()=>{
    console.log(`Server started at:${PORT} `);
})

dbConnect();