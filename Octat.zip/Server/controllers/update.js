const { get } = require("mongoose");
const jobdata= require("../models/data")
const updateJobData = async (req, res) => {
    try {
        const { id, name, location, posted, status, applied, jobViews, daysLeft, premium, dateFormat } = req.body;

        // Check for required fields
        if (!id) {
            return res.status(400).json({
                success: false,
                message: "Job ID is required for updating job data",
            });
        }

        const existingJobData = await jobdata.findOne({ id });

        if (!existingJobData) {
            return res.status(404).json({
                success: false,
                message: "Job data not found",
            });
        }

        // Prepare the fields that need to be updated
        const updateFields = {};
        if (name) updateFields.name = name;
        if (location) updateFields.location = location;
        if (posted) updateFields.posted = posted;
        if (status) updateFields.status = status;
        if (applied) updateFields.applied = applied;
        if (jobViews) updateFields.jobViews = jobViews;
        if (daysLeft) updateFields.daysLeft = daysLeft;
        if (premium) updateFields.premium = premium;
        if (dateFormat) updateFields.dateFormat = dateFormat;

        // Check if any fields need to be updated
        if (Object.keys(updateFields).length === 0) {
            return res.status(400).json({
                success: false,
                message: "No fields provided for updating",
            });
        }

        const updatedJobData = await jobdata.findOneAndUpdate(
            { id },
            updateFields,
            { new: true }
        );

        return res.status(200).json({
            success: true,
            message: "Job data updated successfully",
            updatedJobData,
        });
    } catch (err) {
        return res.status(500).json({
            success: false,
            message: "Failed to update job data",
        });
    }
};
module.exports =  updateJobData;