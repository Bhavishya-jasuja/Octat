const { get } = require("mongoose");
const jobdata= require("../models/data")
const createJobData= async(req,res)=>{
    try{
        const {id,name,location,posted,status,applied,jobViews,daysLeft,premium,dateFormat}=req.body;
        console.log(name);
        
        const newJobData= await jobdata.create({
            id,
            name,
            location,
            posted,
            status,
            applied,
            jobViews,
            daysLeft,
            premium,
            dateFormat
        });
        console.log(newJobData);
        return res.status(200).json({
            success : true,
            message : "job data created successfully",
            newJobData,
        })

    }
    catch(err)
    {
        return res.status(500).json({
            success : false,
            message : "job data not created",
           
        })
    }
}

module.exports =  createJobData;


