const { get } = require("mongoose");
const jobdata= require("../models/data")
const deleteJobData = async (req, res) => {
    try {
        const { id } = req.body;

        const deletedJobData = await jobdata.findOneAndDelete({ id: id });

        if (!deletedJobData) {
            return res.status(404).json({
                success: false,
                message: "Job data not found",
            });
        }

        return res.status(200).json({
            success: true,
            message: "Job data deleted successfully",
            deletedJobData,
        });
    } catch (err) {
        return res.status(500).json({
            success: false,
            message: "Failed to delete job data",
        });
    }
};
module.exports =  deleteJobData;
