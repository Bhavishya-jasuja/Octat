const mongoose = require('mongoose');

const jobData = new mongoose.Schema(
    {
        id:{
            type:Number,
            required:true,
            
        },
        name:{
            type:String,
            required:true,
           

        },
        location:{
            type:String,
            required:true,
         

        },
        posted:{
            type:String,
            required:true,
        },
        
        status:{
            type:String,
          
            required:true,
        },
        applied:{
            type:Number,
            required:true,
          

        },
        jobViews:{
            type:Number,
            required:true,
          

        },
        daysLeft:{
            type:Number,
            required:true,
          

        }, 
        premium:{
            type:Boolean,
            required:true,
          

        }, 
        dateFormat:{
            type:String,
            required:true,
          

        },
       

    }

);

module.exports = mongoose.model("Jobdata",jobData);