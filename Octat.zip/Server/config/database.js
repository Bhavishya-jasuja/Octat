const mongoose = require('mongoose');

require("dotenv").config();

const url = process.env.MONGODB_URL;
console.log(url);


const dbConnect = () =>{
    
    mongoose.connect(process.env.MONGODB_URL,{
        useNewUrlParser:true,
        useUnifiedTopology:true
    })
    .then(() =>{
        console.log("Database connected Sucessfully");
    })
    .catch((err) =>{
        console.log("Database not connected");
        console.error(err);
        process.exit(1);
    })
}

module.exports = dbConnect;