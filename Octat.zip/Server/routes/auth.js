const express = require('express');
const nexus= require("../controllers/nexus")

const router = express.Router();

router.post('/data',nexus);


module.exports = router;